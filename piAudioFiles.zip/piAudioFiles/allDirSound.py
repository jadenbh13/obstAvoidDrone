import sys
import cv2
import numpy as np
import ArducamDepthCamera as ac
import time
from depthWithApf import getDirection
import bluetooth
from openal.audio import SoundSink, SoundSource, SoundData
from openal.loaders import load_wav_file, load_file
import heapq





maxDistance = 12
sink = SoundSink()
sink.activate()
#primeSource = SoundSource()
#primeSource.looping = False
sourceList = []
dh = 0
indexCounter = 0
numSources = 20


while dh < 500:
	source = SoundSource()
	source.looping = False
	sourceList.append(source)
	dh += numSources


def round_to_multiple(number, multiple):
	return multiple * round(number / multiple)



print(dir(ac))

MAX_DISTANCE = 8
divNum = 8


def blur(disps):
	he, we = disps.shape
	yDim = int(he / divNum)
	xDim = int(we / divNum)
	newImX = np.empty((divNum, divNum), int)
	newImY = np.empty((divNum, divNum), int)
	for ye in range(0, divNum):
		yD = yDim * ye
		for xe in range(0, divNum):
			xD = xe * xDim
			#print(xD, yD)
			arrAlt = disps[yD:(yD + yDim), xD:(xD + xDim)]
			#print(arrAlt)
			currMean = int(np.mean(arrAlt))
			newImX[ye][xe] = currMean
			newImY[xe][ye] = currMean
	return newImX, newImY



def process_frame(depth_buf: np.ndarray, amplitude_buf: np.ndarray) -> np.ndarray:
		
	depth_buf = np.nan_to_num(depth_buf)

	amplitude_buf[amplitude_buf<=7] = 0
	amplitude_buf[amplitude_buf>7] = 255

	depth_buf = (1 - (depth_buf/MAX_DISTANCE)) * 255
	depth_buf = np.clip(depth_buf, 0, 255)
	result_frame = depth_buf.astype(np.uint8)  & amplitude_buf.astype(np.uint8)
	return result_frame 

class UserRect():
	def __init__(self) -> None:
		self.start_x = 0
		self.start_y = 0
		self.end_x = 0
		self.end_y = 0

selectRect = UserRect()

followRect = UserRect()

def on_mouse(event, x, y, flags, param):
	global selectRect,followRect
	
	if event == cv2.EVENT_LBUTTONDOWN:
		pass

	elif event == cv2.EVENT_LBUTTONUP:
		selectRect.start_x = x - 4 if x - 4 > 0 else 0
		selectRect.start_y = y - 4 if y - 4 > 0 else 0
		selectRect.end_x = x + 4 if x + 4 < 240 else 240
		selectRect.end_y=  y + 4 if y + 4 < 180 else 180
	else:
		followRect.start_x = x - 4 if x - 4 > 0 else 0
		followRect.start_y = y - 4 if y - 4 > 0 else 0
		followRect.end_x = x + 4 if x + 4 < 240 else 240
		followRect.end_y = y + 4 if y + 4 < 180 else 180
		
def usage(argv0):
	print("Usage: python "+argv0+" [options]")
	print("Available options are:")
	print(" -d		Choose the video to use")


if __name__ == "__main__":
	cam = ac.ArducamCamera()
	if cam.init(ac.TOFConnect.CSI,0) != 0 :
		print("initialization failed")
	if cam.start(ac.TOFOutput.DEPTH) != 0 :
		print("Failed to start camera")
	cam.setControl(ac.TOFControl.RANG,MAX_DISTANCE)
	#cv2.namedWindow("preview", cv2.WINDOW_AUTOSIZE)
	#cv2.setMouseCallback("preview",on_mouse)
	tm0 = time.time()
	sourceMain = SoundSource()
	sourceMain.looping = False
	sourceDatas = load_wav_file("/home/jaden/Arducam_tof_camera/example/python/waveFiles/wave" + str(100) + ".wav")

	while True:
		frame = cam.requestFrame(200)
		if frame != None:
			depth_buf = frame.getDepthData()
			amplitude_buf = frame.getAmplitudeData()
			cam.releaseFrame(frame)
			amplitude_buf*=(1024/1024)
			amplitude_buf = np.clip(amplitude_buf, 0, 255)
			newAmp = 255 - np.uint8(amplitude_buf)
			he, we = newAmp.shape
			newAmp = newAmp[0:he, 0:we]
			heUse = int(he / 2)
			weUse = int(we / 2)
			newAmp = cv2.resize(newAmp, (weUse,heUse), interpolation = cv2.INTER_AREA)
			cv2.imshow("preview_amplitude", newAmp)
			#cv2.imshow("alt", b)
			#newAmp = b
			#bl = blur(redIm)
			#print(bl[0])
			dirs = getDirection(newAmp)
			#print(dirs[0], dirs[1], dirs[2])
			tm1 = time.time()
			tmPrev = tm1 - tm0
			soundMag = dirs[3]
			#soundMag = ((90 - abs(soundMag)) / 7) + 5.0
			mainX = (round(dirs[0], 3) * -1) * 2.0
			mainZ = round(dirs[2], 3) * 2.0
			mainY = (round(dirs[1], 3) * -2.5) + 5
			mainX = round(mainX, 2)
			mainZ = round(mainZ, 2)
			#yCord = (round(dirs[1], 3) * 4.0)
			if mainY < 2.5:
				mainY = 2.5
			elif mainY > 7.5:
				mainY = 7.5
			newPitch = mainY
			#indx = int(mainY / numSources)
			#indx = 20
			print(mainX, mainZ, newPitch, dirs[1])
			sourceMain.pitch = newPitch
			sourceMain.queue(sourceDatas)
			sourceMain.position = [mainX, mainZ, 0]
			#print(mainX, mainZ)
			sink.play(sourceMain)
			#print(f"X: {mainX}, Y: {mainY}, Z: {mainZ}")
			#print(soundMag)
			sink.update()
			#print(tmPrev)
			tm0 = tm1
			key = cv2.waitKey(1)
			if key == ord("q"):
				exit_ = True
				cam.stop()
				sys.exit(0)
				break
			#sourceMainDatas = load_file("/home/jaden/Arducam_tof_camera/example/python/waveFiles/wave" + str(mainY) + ".wav")
			#sourceMain.queue(sourceMainDatas)
			#sink.update()
