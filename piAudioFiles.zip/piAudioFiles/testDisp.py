import cv2
import matplotlib.pyplot as plt
import time
import numpy as np
from depthWithApf import getDirection
import bluetooth
from openal.audio import SoundSink, SoundSource, SoundData
from openal.loaders import load_wav_file, load_file


cam = cv2.VideoCapture(0)
cam2 = cv2.VideoCapture(2)

vt = 0





block_size = 5
min_disp = 0
max_disp = 64
# Maximum disparity minus minimum disparity. The value is always greater than zero.
# In the current implementation, this parameter must be divisible by 16.
num_disp = max_disp - min_disp
# Margin in percentage by which the best (minimum) computed cost function value should "win" the second best value to consider the found match correct.
# Normally, a value within the 5-15 range is good enough
uniquenessRatio = 7
# Maximum size of smooth disparity regions to consider their noise speckles and invalidate.
# Set it to 0 to disable speckle filtering. Otherwise, set it somewhere in the 50-200 range.
speckleWindowSize = 200
# Maximum disparity variation within each connected component.
# If you do speckle filtering, set the parameter to a positive value, it will be implicitly multiplied by 16.
# Normally, 1 or 2 is good enough.
speckleRange = 2
disp12MaxDiff = 0

stereo = cv2.StereoSGBM_create(
    minDisparity=min_disp,
    numDisparities=num_disp,
    blockSize=block_size,
    uniquenessRatio=uniquenessRatio,
    speckleWindowSize=speckleWindowSize,
    speckleRange=speckleRange,
    disp12MaxDiff=disp12MaxDiff,
    P1=8 * 1 * block_size * block_size,
    P2=32 * 1 * block_size * block_size,
)


mainDiv = 5
subMag = 55

while True:
	ret, image = cam.read()
	he, we, ce = image.shape
	heN = int(he / mainDiv)
	weN = int(we / mainDiv)
	newImage = image[0:(he-subMag), 0:we]
	newImage = cv2.resize(newImage, (weN, heN), interpolation=cv2.INTER_AREA)
	gray1 = cv2.cvtColor(newImage, cv2.COLOR_BGR2GRAY)
	
	ret2, image2 = cam2.read()
	he2, we2, ce2 = image2.shape
	heN2 = int(he2 / mainDiv)
	weN2 = int(we2 / mainDiv)
	newImage2 = image2[subMag:he2, 0:we2]
	newImage2 = cv2.resize(newImage2, (weN2, heN2), interpolation=cv2.INTER_AREA)
	gray2 = cv2.cvtColor(newImage2, cv2.COLOR_BGR2GRAY)
	#gray1 = newImage
	#gray2 = newImage2	
	#print(ster)
	#print(type(ster))
	#print(ster.shape)
	#print(vt)
	#print(newImage.shape)
	#print(newImage2.shape)
	cv2.imshow("L", newImage)
	cv2.imshow("R", newImage2)
	disparity_SGBM = stereo.compute(newImage, newImage2)
	disparity_SGBM = cv2.normalize(disparity_SGBM, disparity_SGBM, alpha=255,
								  beta=0, norm_type=cv2.NORM_MINMAX)
	disparity_SGBMs = np.uint8(disparity_SGBM)
	shap = disparity_SGBMs.shape
	disparity_SGBMs = disparity_SGBMs[0:shap[0], 70:shap[1]]
	disparity_SGBMs = 255 - disparity_SGBMs
	dispser = disparity_SGBMs
	dirs = getDirection(dispser)
	dh, dw = dispser.shape
	dispShow = dispser.copy()
	dispShow = cv2.resize(dispShow, ((dw * 2), (dh * 2)), interpolation=cv2.INTER_LINEAR)
	cv2.imshow('gray', dispShow)
	xMain = round(dirs[0], 3)
	yMain = round(dirs[1], 3)
	
	print(xMain, yMain)
	
	k = cv2.waitKey(1)
	if k == ord(' '):
		cv2.imwrite("leftIm.png", newImage)
		cv2.imwrite("rightIm.png", newImage2)
		"""time.sleep(1)
		img1_undistorted = cv2.imread("leftIm.png")
		img2_undistorted = cv2.imread("rightIm.png")
		disparity_SGBM = stereo.compute(newImage, newImage2)
		disparity_SGBM = cv2.normalize(disparity_SGBM, disparity_SGBM, alpha=255,
									  beta=0, norm_type=cv2.NORM_MINMAX)
		disparity_SGBMs = np.uint8(disparity_SGBM)
		shap = disparity_SGBMs.shape
		#disparity_SGBMs = disparity_SGBMs[0:shap[0], 160:shap[1]]
		disparity_SGBMs = 255 - disparity_SGBMs
		dispser = disparity_SGBMs
		cv2.imshow('gray', dispser)
		print(dispser)
		k = cv2.waitKey(0)"""
		break
	vt += 1
cam.release()
cam2.release()
cv2.destroyAllWindows()
